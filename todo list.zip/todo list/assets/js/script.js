// script.js

document.addEventListener("DOMContentLoaded", () => {
    loadTasks();
    checkDarkMode();
    requestNotificationPermission();
});



function login() {
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;
    
    if (username === "admin" && password === "password") {
        document.getElementById("loginPage").classList.add("hidden");
        document.getElementById("todoPage").classList.remove("hidden");
    } else {
        alert("Invalid username or password");
    }
}



function addTask() {
    let taskInput = document.getElementById("taskInput");
    let dueDate = document.getElementById("dueDate").value;
    let category = document.getElementById("taskCategory").value;
    let taskText = taskInput.value.trim();
    if (taskText === "") return;
    
    let li = document.createElement("li");
    li.innerHTML = `<input type='checkbox' class='task-checkbox' onclick='toggleTask(this)'> 
                    <span class='task-text'>${taskText}</span> 
                    <span class='category-label'>[${category}]</span>
                    <span class='due-date'>${dueDate ? "Due: " + dueDate : ""}</span>
                    <button class='edit-btn' onclick='editTask(this)'>✏️</button>
                    <button class='delete-btn' onclick='deleteTask(this)'>❌</button>`;
    
    document.getElementById("taskList").appendChild(li);
    saveTasks();
    taskInput.value = "";
    document.getElementById("dueDate").value = "";
    playAddSound();
    sendTaskNotification(taskText, dueDate);
    updateProgress();
}

function deleteTask(button) {
    button.parentElement.remove();
    saveTasks();
    updateProgress();
}

function toggleTask(checkbox) {
    let taskItem = checkbox.parentElement;
    if (checkbox.checked) {
        taskItem.classList.add("completed");
    } else {
        taskItem.classList.remove("completed");
    }
    saveTasks();
    updateProgress();
}

function editTask(button) {
    let taskItem = button.parentElement;
    let taskTextElement = taskItem.querySelector(".task-text");
    let newText = prompt("Edit your task:", taskTextElement.textContent);
    if (newText !== null && newText.trim() !== "") {
        taskTextElement.textContent = newText;
        saveTasks();
    }
}

function saveTasks() {
    let tasks = [];
    document.querySelectorAll("#taskList li").forEach(task => {
        tasks.push({
            text: task.querySelector(".task-text").textContent,
            category: task.querySelector(".category-label").textContent.replace("[", "").replace("]", ""),
            dueDate: task.querySelector(".due-date").textContent.replace("Due: ", ""),
            completed: task.classList.contains("completed")
        });
    });
    localStorage.setItem("tasks", JSON.stringify(tasks));
}

function loadTasks() {
    let savedTasks = JSON.parse(localStorage.getItem("tasks")) || [];
    savedTasks.forEach(task => {
        let li = document.createElement("li");
        li.innerHTML = `<input type='checkbox' class='task-checkbox' onclick='toggleTask(this)' ${task.completed ? "checked" : ""}>
                        <span class='task-text'>${task.text}</span>
                        <span class='category-label'>[${task.category}]</span>
                        <span class='due-date'>${task.dueDate ? "Due: " + task.dueDate : ""}</span>
                        <button class='edit-btn' onclick='editTask(this)'>✏️</button>
                        <button class='delete-btn' onclick='deleteTask(this)'>❌</button>`;
        if (task.completed) li.classList.add("completed");
        document.getElementById("taskList").appendChild(li);
    });
    updateProgress();
}

function playAddSound() {
    let audio = new Audio("https://www.fesliyanstudios.com/play-mp3/4384");
    audio.play();
}

function sendTaskNotification(task, dueDate) {
    if (Notification.permission === "granted" && dueDate) {
        new Notification("Task Reminder", {
            body: `Don't forget: ${task} is due on ${dueDate}!`,
            icon: "https://cdn-icons-png.flaticon.com/512/1827/1827314.png"
        });
    }
}

function requestNotificationPermission() {
    if ("Notification" in window) {
        Notification.requestPermission().then(permission => {
            console.log("Notification permission: ", permission);
        });
    }
}

function startVoiceInput() {
    const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.start();
    recognition.onresult = event => {
        let transcript = event.results[0][0].transcript;
        document.getElementById("taskInput").value = transcript;
    };
}

function updateProgress() {
    let totalTasks = document.querySelectorAll("#taskList li").length;
    let completedTasks = document.querySelectorAll("#taskList li.completed").length;
    let progressText = document.getElementById("progress");
    progressText.textContent = `Completed: ${completedTasks} / ${totalTasks}`;
}

// Dark Mode Toggle
function toggleDarkMode() {
    document.body.classList.toggle("dark-mode");
    localStorage.setItem("darkMode", document.body.classList.contains("dark-mode"));
}

function checkDarkMode() {
    if (localStorage.getItem("darkMode") === "true") {
        document.body.classList.add("dark-mode");
    }
}